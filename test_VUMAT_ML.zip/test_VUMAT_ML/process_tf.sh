#!/bin/bash -l

module load python-data
module load intel-oneapi-compilers
export PATH=$PATH:/users/nguyenb5/.local/bin/
process_model -o LSTM.f90  LSTM/saved_model.pb